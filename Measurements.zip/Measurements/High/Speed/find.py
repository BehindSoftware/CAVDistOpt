import re

def find_largest_number_in_file(filename):
    try:
        with open(filename, 'r', encoding='utf-8') as file:
            content = file.read()

        # Dosyadaki tüm sayıları (tam sayı ve ondalık dahil) bul
        numbers = re.findall(r'-?\d+\.?\d*', content)

        if not numbers:
            print("Dosyada sayı bulunamadı.")
            return

        # Sayıları float'a çevir ve en büyüğünü bul
        numbers = [float(num) for num in numbers]
        largest_number = max(numbers)

        print(f"Dosyadaki en büyük sayı: {largest_number}")

    except FileNotFoundError:
        print("Dosya bulunamadı. Lütfen dosya yolunu kontrol edin.")
    except Exception as e:
        print(f"Bir hata oluştu: {e}")


# Örnek kullanım
if __name__ == "__main__":
    filename = input("Dosya adını veya yolunu girin: ")
    find_largest_number_in_file(filename)
